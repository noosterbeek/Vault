// =============================================================================
// VaultCertReader
// Reads a secret from HashiCorp Vault. Authentication uses the TLS certificate
// auth method (auth/cert): the client certificate is taken from the Windows
// certificate store by thumbprint and presented during the TLS handshake (mTLS).
//
// Flow:
//   1. Load the certificate (with private key) from the store by thumbprint.
//   2. POST {Address}/v1/auth/{AuthMountPath}/login over mTLS -> client token.
//   3. GET  the secret from the KV engine with header X-Vault-Token.
//        KV v2: {Address}/v1/{KvMountPath}/data/{SecretPath}  -> data.data
//        KV v1: {Address}/v1/{KvMountPath}/{SecretPath}       -> data
//   4. Optionally revoke the token (auth/token/revoke-self).
//
// Output:
//   - SecretKey set:   only the value of that key is written to stdout.
//   - SecretKey empty: all key/value pairs are written to stdout as JSON.
//   Diagnostic messages are written to stderr.
//
// Configuration (later sources override earlier ones):
//   1. appsettings.json            (section "Vault")
//   2. Environment variables       (e.g. Vault__SecretPath=myapp/db)
//   3. Command-line arguments      (e.g. --SecretPath myapp/db --SecretKey password)
//
// Exit codes: 0 = success, 1 = configuration error, 2 = certificate error,
//             3 = Vault login error, 4 = secret read error.
// =============================================================================

using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;

namespace VaultCertReader;

internal static class Program
{
    // Command-line switches mapped to configuration keys.
    private static readonly Dictionary<string, string> SwitchMappings = new()
    {
        ["--Address"] = "Vault:Address",
        ["--Namespace"] = "Vault:Namespace",
        ["--CertificateThumbprint"] = "Vault:CertificateThumbprint",
        ["--Thumbprint"] = "Vault:CertificateThumbprint",
        ["--StoreLocation"] = "Vault:StoreLocation",
        ["--StoreName"] = "Vault:StoreName",
        ["--AuthMountPath"] = "Vault:AuthMountPath",
        ["--AuthRoleName"] = "Vault:AuthRoleName",
        ["--KvMountPath"] = "Vault:KvMountPath",
        ["--KvVersion"] = "Vault:KvVersion",
        ["--SecretPath"] = "Vault:SecretPath",
        ["--SecretKey"] = "Vault:SecretKey",
        ["--RevokeTokenAfterUse"] = "Vault:RevokeTokenAfterUse",
    };

    private static async Task<int> Main(string[] args)
    {
        VaultSettings settings;
        try
        {
            settings = LoadSettings(args);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Configuration error: {ex.Message}");
            return 1;
        }

        X509Certificate2 certificate;
        try
        {
            certificate = CertificateLoader.LoadFromStore(
                settings.CertificateThumbprint, settings.StoreLocation, settings.StoreName);
            Console.Error.WriteLine(
                $"Using certificate '{certificate.Subject}' (valid until {certificate.NotAfter.ToUniversalTime():u}).");
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Certificate error: {ex.Message}");
            return 2;
        }

        using (certificate)
        using (var vault = new VaultClient(settings, certificate))
        {
            string token;
            try
            {
                token = await vault.LoginAsync();
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Vault login failed: {ex.Message}");
                return 3;
            }

            try
            {
                JsonObject data = await vault.ReadSecretAsync(token);

                if (string.IsNullOrWhiteSpace(settings.SecretKey))
                {
                    Console.WriteLine(data.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
                }
                else
                {
                    if (!data.TryGetPropertyValue(settings.SecretKey, out JsonNode? value) || value is null)
                    {
                        Console.Error.WriteLine(
                            $"Key '{settings.SecretKey}' not found in secret '{settings.SecretPath}'. " +
                            $"Available keys: {string.Join(", ", data.Select(p => p.Key))}.");
                        return 4;
                    }

                    // Strings are written without quotes; other JSON types as JSON.
                    Console.WriteLine(value is JsonValue v && v.TryGetValue(out string? s) ? s : value.ToJsonString());
                }

                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Reading secret failed: {ex.Message}");
                return 4;
            }
            finally
            {
                if (settings.RevokeTokenAfterUse)
                    await vault.TryRevokeTokenAsync(token);
            }
        }
    }

    private static VaultSettings LoadSettings(string[] args)
    {
        IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .AddCommandLine(args, SwitchMappings)
            .Build();

        IConfigurationSection section = config.GetSection("Vault");

        string address = Required(section, "Address").TrimEnd('/');
        if (!Uri.TryCreate(address, UriKind.Absolute, out Uri? uri) || uri.Scheme != Uri.UriSchemeHttps)
            throw new ArgumentException($"Address '{address}' must be a valid https URL (certificate auth requires TLS).");

        int kvVersion = int.TryParse(section["KvVersion"], out int kv) ? kv : 2;
        if (kvVersion != 1 && kvVersion != 2)
            throw new ArgumentException("KvVersion must be 1 or 2.");

        return new VaultSettings
        {
            Address = address,
            Namespace = section["Namespace"]?.Trim() ?? "",
            CertificateThumbprint = Required(section, "CertificateThumbprint"),
            StoreLocation = ParseEnum(section["StoreLocation"], StoreLocation.CurrentUser, "StoreLocation"),
            StoreName = ParseEnum(section["StoreName"], StoreName.My, "StoreName"),
            AuthMountPath = TrimPath(section["AuthMountPath"], "cert"),
            AuthRoleName = section["AuthRoleName"]?.Trim() ?? "",
            KvMountPath = TrimPath(section["KvMountPath"], "secret"),
            KvVersion = kvVersion,
            SecretPath = TrimPath(Required(section, "SecretPath"), ""),
            SecretKey = section["SecretKey"]?.Trim() ?? "",
            RevokeTokenAfterUse = !bool.TryParse(section["RevokeTokenAfterUse"], out bool revoke) || revoke,
        };
    }

    private static string Required(IConfigurationSection section, string key)
    {
        string? value = section[key];
        if (string.IsNullOrWhiteSpace(value) || value.StartsWith('<'))
            throw new ArgumentException($"Setting '{key}' is missing (appsettings.json, Vault__{key} or --{key}).");
        return value.Trim();
    }

    private static string TrimPath(string? value, string defaultValue) =>
        string.IsNullOrWhiteSpace(value) ? defaultValue : value.Trim().Trim('/');

    private static T ParseEnum<T>(string? value, T defaultValue, string key) where T : struct, Enum
    {
        if (string.IsNullOrWhiteSpace(value))
            return defaultValue;
        if (Enum.TryParse(value, ignoreCase: true, out T result))
            return result;
        throw new ArgumentException(
            $"Setting '{key}' has invalid value '{value}'. Allowed: {string.Join(", ", Enum.GetNames<T>())}.");
    }
}

/// <summary>Settings for connecting to HashiCorp Vault.</summary>
internal sealed class VaultSettings
{
    public string Address { get; init; } = "";
    public string Namespace { get; init; } = "";
    public string CertificateThumbprint { get; init; } = "";
    public StoreLocation StoreLocation { get; init; } = StoreLocation.CurrentUser;
    public StoreName StoreName { get; init; } = StoreName.My;
    public string AuthMountPath { get; init; } = "cert";
    public string AuthRoleName { get; init; } = "";
    public string KvMountPath { get; init; } = "secret";
    public int KvVersion { get; init; } = 2;
    public string SecretPath { get; init; } = "";
    public string SecretKey { get; init; } = "";
    public bool RevokeTokenAfterUse { get; init; } = true;
}

/// <summary>Minimal HashiCorp Vault HTTP API client using TLS certificate authentication.</summary>
internal sealed class VaultClient : IDisposable
{
    private readonly VaultSettings _settings;
    private readonly HttpClient _http;

    public VaultClient(VaultSettings settings, X509Certificate2 clientCertificate)
    {
        _settings = settings;

        // The client certificate is presented during the TLS handshake (mTLS).
        // The Vault server certificate is validated against the Windows trusted root store.
        var handler = new HttpClientHandler
        {
            ClientCertificateOptions = ClientCertificateOption.Manual,
        };
        handler.ClientCertificates.Add(clientCertificate);

        _http = new HttpClient(handler)
        {
            BaseAddress = new Uri(settings.Address + "/"),
            Timeout = TimeSpan.FromSeconds(30),
        };
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        // Vault Enterprise namespace (optional).
        if (!string.IsNullOrEmpty(settings.Namespace))
            _http.DefaultRequestHeaders.Add("X-Vault-Namespace", settings.Namespace);
    }

    /// <summary>Logs in with the TLS certificate auth method and returns the client token.</summary>
    public async Task<string> LoginAsync()
    {
        // The "name" field selects a specific certificate role; if omitted, Vault
        // tries all roles that match the presented certificate.
        var body = new JsonObject();
        if (!string.IsNullOrEmpty(_settings.AuthRoleName))
            body["name"] = _settings.AuthRoleName;

        using var content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json");
        using HttpResponseMessage response = await _http.PostAsync($"v1/auth/{_settings.AuthMountPath}/login", content);

        JsonNode json = await ReadJsonAsync(response, "login");

        string? token = json["auth"]?["client_token"]?.GetValue<string>();
        if (string.IsNullOrEmpty(token))
            throw new InvalidOperationException("Login response contains no client token.");

        Console.Error.WriteLine("Logged in to Vault.");
        return token;
    }

    /// <summary>Reads the secret and returns its key/value pairs.</summary>
    public async Task<JsonObject> ReadSecretAsync(string token)
    {
        string path = _settings.KvVersion == 2
            ? $"v1/{_settings.KvMountPath}/data/{_settings.SecretPath}"
            : $"v1/{_settings.KvMountPath}/{_settings.SecretPath}";

        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        request.Headers.Add("X-Vault-Token", token);

        using HttpResponseMessage response = await _http.SendAsync(request);
        JsonNode json = await ReadJsonAsync(response, "read secret");

        // KV v2 wraps the values in data.data; KV v1 returns them in data.
        JsonNode? data = _settings.KvVersion == 2 ? json["data"]?["data"] : json["data"];

        return data as JsonObject
            ?? throw new InvalidOperationException("Secret response contains no data (deleted or destroyed version?).");
    }

    /// <summary>Revokes the token; failures are reported but not fatal.</summary>
    public async Task TryRevokeTokenAsync(string token)
    {
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, "v1/auth/token/revoke-self");
            request.Headers.Add("X-Vault-Token", token);
            using HttpResponseMessage response = await _http.SendAsync(request);
            if (!response.IsSuccessStatusCode)
                Console.Error.WriteLine($"Warning: token revoke returned {(int)response.StatusCode}.");
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Warning: token revoke failed: {ex.Message}");
        }
    }

    /// <summary>Parses a Vault JSON response and turns error responses into readable exceptions.</summary>
    private async Task<JsonNode> ReadJsonAsync(HttpResponseMessage response, string operation)
    {
        string body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            // Vault returns errors as {"errors": ["..."]}.
            string details = "";
            try
            {
                if (JsonNode.Parse(body)?["errors"] is JsonArray errors && errors.Count > 0)
                    details = string.Join("; ", errors.Select(e => e?.ToString()));
            }
            catch (JsonException) { /* non-JSON error body */ }

            string hint = response.StatusCode switch
            {
                HttpStatusCode.BadRequest when operation == "login" =>
                    " (certificate not accepted: check the cert role and its trusted CA / allowed names)",
                HttpStatusCode.Forbidden => operation == "login"
                    ? " (certificate not accepted by the cert auth method)"
                    : $" (token policy does not allow 'read' on {response.RequestMessage?.RequestUri?.AbsolutePath})",
                HttpStatusCode.NotFound => " (path not found: check KvMountPath, KvVersion and SecretPath)",
                _ => "",
            };

            throw new InvalidOperationException(
                $"{operation} failed with HTTP {(int)response.StatusCode}{hint}" +
                (details.Length > 0 ? $": {details}" : "."));
        }

        return JsonNode.Parse(body) ?? throw new InvalidOperationException($"{operation}: empty response.");
    }

    public void Dispose() => _http.Dispose();
}

/// <summary>Loads a certificate from the Windows certificate store by thumbprint.</summary>
internal static class CertificateLoader
{
    public static X509Certificate2 LoadFromStore(string thumbprint, StoreLocation location, StoreName name)
    {
        // Thumbprints copied from the certificate dialog (certmgr.msc) often contain
        // spaces or an invisible U+200E character; keep only hex digits.
        string cleanThumbprint = Regex.Replace(thumbprint, "[^0-9A-Fa-f]", "").ToUpperInvariant();
        if (cleanThumbprint.Length != 40)
            throw new ArgumentException(
                $"Thumbprint must be 40 hex characters (SHA-1); got {cleanThumbprint.Length}.");

        using var store = new X509Store(name, location);
        store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

        // validOnly: false so an expired or untrusted certificate is still found and
        // the exact reason can be reported below instead of "not found".
        X509Certificate2Collection matches =
            store.Certificates.Find(X509FindType.FindByThumbprint, cleanThumbprint, validOnly: false);

        if (matches.Count == 0)
            throw new InvalidOperationException(
                $"No certificate with thumbprint {cleanThumbprint} in {location}\\{name}.");

        X509Certificate2 cert = matches[0];
        for (int i = 1; i < matches.Count; i++)
            matches[i].Dispose();

        DateTime now = DateTime.Now;
        if (cert.NotAfter < now)
            throw new InvalidOperationException($"Certificate expired on {cert.NotAfter.ToUniversalTime():u}.");
        if (cert.NotBefore > now)
            throw new InvalidOperationException($"Certificate is not valid until {cert.NotBefore.ToUniversalTime():u}.");

        if (!cert.HasPrivateKey)
            throw new InvalidOperationException(
                "Certificate has no private key. Import the .pfx (not the .cer) into the store.");

        return cert;
    }
}
