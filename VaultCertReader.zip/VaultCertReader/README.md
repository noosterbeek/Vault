# VaultCertReader

Console app (.NET 8, Windows) that reads a secret from **HashiCorp Vault**.
It logs in with the **TLS certificate auth method** (`auth/cert`), using a client
certificate from the Windows certificate store selected by thumbprint (mTLS),
and then reads the secret from a KV engine (v1 or v2).

## Prerequisites (Vault)

1. Enable the cert auth method (once):
   ```bash
   vault auth enable cert
   ```
2. Create a policy that allows reading the secret, e.g. `myapp-read.hcl`:
   ```hcl
   # KV v2
   path "secret/data/myapp/*" {
     capabilities = ["read"]
   }
   ```
   ```bash
   vault policy write myapp-read myapp-read.hcl
   ```
3. Create a cert role with the CA (or the client certificate itself) that Vault must trust:
   ```bash
   vault write auth/cert/certs/myapp \
       display_name=myapp \
       policies=myapp-read \
       certificate=@ca-or-client-cert.pem \
       ttl=5m
   ```
4. The Vault listener must accept client certificates (default for TLS listeners,
   unless `tls_disable_client_certs = true`).

## Prerequisites (Windows)

- The client certificate **with private key** (`.pfx`) is imported in
  `CurrentUser\My` or `LocalMachine\My`.
- For `LocalMachine`: the account running the app needs read access to the private key
  (certlm.msc → certificate → All Tasks → Manage Private Keys).
- The certificate must allow **Client Authentication** (EKU 1.3.6.1.5.5.7.3.2) or have no EKU.
- The CA that issued the **Vault server** certificate must be trusted on the machine
  (Trusted Root Certification Authorities).

## Configuration

Edit `appsettings.json` (section `Vault`):

| Setting | Default | Description |
|---|---|---|
| Address | | `https://vault.example.com:8200` (https required) |
| Namespace | empty | Vault Enterprise namespace (sent as `X-Vault-Namespace`) |
| CertificateThumbprint | | Thumbprint of the client certificate (spaces allowed) |
| StoreLocation | CurrentUser | `CurrentUser` or `LocalMachine` |
| StoreName | My | Certificate store name |
| AuthMountPath | cert | Mount path of the cert auth method |
| AuthRoleName | empty | Cert role name (e.g. `myapp`); empty = Vault tries all matching roles |
| KvMountPath | secret | Mount path of the KV engine |
| KvVersion | 2 | `1` or `2` |
| SecretPath | | Path of the secret within the KV mount, e.g. `myapp/db` |
| SecretKey | empty | Key to return (e.g. `password`); empty = all keys as JSON |
| RevokeTokenAfterUse | true | Revoke the Vault token when done |

Every setting can be overridden:
- environment variable: `Vault__SecretPath=myapp/db`
- command line: `--SecretPath myapp/db --SecretKey password` (also `--Thumbprint` as short form)

## Build and run

```powershell
dotnet build -c Release
dotnet run -- --SecretPath myapp/db --SecretKey password
```

Publish as a single exe:
```powershell
dotnet publish -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -o .\publish
.\publish\VaultCertReader.exe --SecretPath myapp/db --SecretKey password
```

Only the secret goes to **stdout**; diagnostics go to **stderr**:
```powershell
$dbPassword = .\VaultCertReader.exe --SecretPath myapp/db --SecretKey password
```

## Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Configuration error |
| 2 | Certificate error (not found, expired, no private key) |
| 3 | Vault login failed (certificate not accepted, TLS error, ...) |
| 4 | Reading the secret failed (403 policy, 404 path, key not found) |

## Test with the Vault CLI

```bash
vault login -method=cert -client-cert=client.pem -client-key=client.key name=myapp
vault kv get -mount=secret myapp/db
```

## Find the thumbprint

```powershell
Get-ChildItem Cert:\CurrentUser\My | Select-Object Thumbprint, Subject, NotAfter
Get-ChildItem Cert:\LocalMachine\My | Select-Object Thumbprint, Subject, NotAfter
```
